package com.binance.api.client.domain.general;

/**
 * Rate limiters.
 */
public enum RateLimitType {
  REQUESTS,
  ORDERS
}
