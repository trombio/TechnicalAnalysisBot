package com.binance.api.client.domain;

/**
 * Buy/Sell order side.
 */
public enum OrderSide {
  BUY,
  SELL
}
